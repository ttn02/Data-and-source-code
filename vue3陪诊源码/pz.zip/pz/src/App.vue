<script setup></script>

<template>
  <RouterView />
</template>

<style>
#app,
body,
html {
  margin: 0;
  padding: 0;
}
</style>
